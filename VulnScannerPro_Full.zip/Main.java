import core.ScannerEngine;

public class Main {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: java Main <target URL>");
            return;
        }
        String target = args[0];
        ScannerEngine engine = new ScannerEngine(target);
        engine.runAll();
    }
}
