package core;

import modules.*;
import java.util.*;
import java.util.concurrent.*;

public class ScannerEngine {
    private final List<Runnable> scanners = new ArrayList<>();

    public ScannerEngine(String target) {
        scanners.add(new HttpHeaderScanner(target));
        scanners.add(new CVEChecker(target));
    }

    public void runAll() {
        ExecutorService executor = Executors.newFixedThreadPool(scanners.size());
        List<Future<?>> futures = new ArrayList<>();

        for (Runnable scanner : scanners) {
            futures.add(executor.submit(scanner));
        }

        for (Future<?> f : futures) {
            try {
                f.get();
            } catch (Exception e) {
                System.out.println("Scan error: " + e.getMessage());
            }
        }

        executor.shutdown();
    }
}
