package utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

public class HttpUtils {
    public static HashMap<String, String> fetchHeaders(String targetUrl) throws Exception {
        HashMap<String, String> headers = new HashMap<>();
        URL url = new URL(targetUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();

        for (int i = 0;; i++) {
            String headerKey = conn.getHeaderFieldKey(i);
            String headerValue = conn.getHeaderField(i);
            if (headerKey == null && headerValue == null) break;
            if (headerKey != null && headerValue != null) {
                headers.put(headerKey, headerValue);
            }
        }
        conn.disconnect();
        return headers;
    }

    public static String fetchBody(String targetUrl) throws Exception {
        URL url = new URL(targetUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append("\n");
        }
        reader.close();
        conn.disconnect();
        return sb.toString();
    }
}
