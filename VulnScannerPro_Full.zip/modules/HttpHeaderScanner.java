package modules;

import java.net.HttpURLConnection;
import java.net.URL;

public class HttpHeaderScanner implements Runnable {
    private final String target;

    public HttpHeaderScanner(String target) {
        this.target = target;
    }

    public void run() {
        System.out.println("[HttpHeaderScanner]");
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(target).openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            System.out.println("Server: " + conn.getHeaderField("Server"));
            System.out.println("X-Powered-By: " + conn.getHeaderField("X-Powered-By"));
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Header scan error: " + e.getMessage());
        }
    }
}
