package modules;

import java.io.*;
import java.util.*;
import org.json.*;

public class CVEChecker implements Runnable {
    private final String target;

    public CVEChecker(String target) {
        this.target = target;
    }

    public void run() {
        System.out.println("[CVEChecker]");
        try {
            String banner = "Apache/2.4.49"; // Example: should be parsed from actual response
            File file = new File("data/cve_db.json");
            StringBuilder sb = new StringBuilder();
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                sb.append(sc.nextLine());
            }
            JSONArray cves = new JSONArray(sb.toString());
            for (int i = 0; i < cves.length(); i++) {
                JSONObject obj = cves.getJSONObject(i);
                if (banner.contains(obj.getString("product"))) {
                    System.out.println("Found CVE: " + obj.getString("id") + " - " + obj.getString("description"));
                }
            }
        } catch (Exception e) {
            System.out.println("CVE check error: " + e.getMessage());
        }
    }
}
